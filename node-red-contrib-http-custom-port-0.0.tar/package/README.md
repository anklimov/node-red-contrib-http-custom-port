Based off the built-in NodeRED HTTP node, but with added capability to start its own express instance to receive requests on another port.
Additionally with  node-red-contrib-http-custom-port, allowed to skip automatical body to JSON parsing and gain access to raw request body (use the  appropriate checkbox)
